import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
 
public class MainGUI extends JFrame{
	//Ϊ��װ�ƶ�ǿ��ʹ��δ���GUI������
	public MainGUI(){
		JButton jbtOK = new JButton("OK");
		setLayout(new FlowLayout());
		add(jbtOK);
		
		ActionListener listener = new OKListener();
		jbtOK.addActionListenner(listener);
	}
	
	/** Main method */
	public static void main(String[] args) throws Exception{
		
		//GUI
		JFrame frame=new MainGUI();
		frame.setTitle("MainGUI");
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_ClOSE);
		frame.setSize(220,80);
		frame.setVisible(true);
		
		java.io.File file = new java.io.File("C:\\Users\\Administrator\\Desktop\\hh\\scores.txt");
		java.util.Scanner input = new java.util.Scanner(file);
		
		//Read data from the txt
		
		String[] string=new String[24];// I have known that there are 24 subjects which has grades.
		for(int u=0;u<=23;u++)
			string[u]=" ";
		int n=0;
		//Read data from the txt
		while(input.hasNextLine()){
			string[n]=input.nextLine();
			n++;
		}
		
		//�˴�����δ�ܽ�������⡣����
		int[] grade=new int[24];
		int[] grade2=new int[24];
		for(int n2=0;n2<=23;n2++){
			String gra1=string[n2];
			String gra2=gra1.substring(gra1.length()-2);
			grade[n2]=Integer.parseInt(gra2);
		}
		
		for(int p=0;p<=23;p++)
			grade2[p]=grade[p];
		Sort(grade);
		
		//���ݳɼ�ƥ��ÿ�ȫ����Ϣ����
		int q = 0;
		String finalString=string[0] + "\n";
		while(q<=23){
		if(q==0||grade[q] !=grade[q-1]){
			for(int w=0;w<=23;w++){
			if(grade2[w]==grade[q])
				finalString=finalString+string[w]+"\n";
			}
			q++;
		}
		else
			q++;
		}
		
		//��ӡ���µ��ĵ���
		File f =new File("C:\\Users\\Administrator\\Desktop\\hh\\NewScores.txt");
		FileWriter fileWriter=new FileWriter(f);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		finalString = finalString.replaceAll("\n","\r\\n");
		fileWriter.write(finalString);
		fileWriter.flush();
		
		String[] a = new String[24];
		String[] b = new String[24];
		String[] c = new String[24];
		double[] d = new double[24];
		String[] e = new String[24];
		String[] fn = new String[24];
		String[] g = new String[24];
		String[] h = new String[24];
		String[] i = new String[24];
		int[] j = new int[24];
		int m=0;
		while(input.hasNextLine()){
			a[m]=input.next();
			b[m]=input.next();
			c[m]=input.next();
			d[m]=input.nextDouble();//ѧ��
			e[m]=input.next();
			fn[m]=input.next();
			g[m]=input.next();
			h[m]=input.next();
			i[m]=input.next();
			j[m]=input.nextInt();//�ɼ�
			m++;
		}
		
		
		double finalEqualGrade=CalculateGPA(d,j);
		double GPA=finalEqualGrade/25;
		GPA=((int)GPA*100)/100;
		java.io.PrintWriter output = new java.io.PrintWriter(f);
		output.println("The finalEqualGrade is " + finalEqualGrade);
		output.print("The GPA is " + GPA);
		
		
		//Close the file
		input.close();
		output.close();
	}
	
	//GUI
	class OKListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			JOptionPane.showMessageDialog(null,
			"That's all!");
		}
	}
	
	//һ�ֱȽϼ򵥴ֱ�����������(ѡ������)������Ȼ����Ҳ�������߼��ġ�����
	public static void Sort(int[] gra){
		SelectionSort.selectionSort(gra);
	}
	//����ƽ���ּ�GPA
	public static double CalculateGPA(double[] arr1,int[] arr2){
		int k = arr1.length();
		double finalGrade= 0;
		double credit=0;
		for(int k2=0;k2<=k-1;k2++){
			finalGrade += arr1[k2]*arr2[k2];
			credit+=arr1[k2];
		}
		double finalEqualGrade=finalGrade/credit;
		return finalEqualGrade;
	}
	
}













			
			
			
			
			